This is a simple program in C# using MS Visual Studio 2026 Community Oct 2026 version 18.11.0 Instance 7c0309a8.
I am offering this as an example to get started using the DSD Tech SH-UR04A quickly.   

Follow the DSD Tech instructions to install the driver.  I installed the driver for Windows 11 from CP210x_Universal_Windows_Driver.  

You can determine which COMport the device is using by plugging it into a USB port, and run the Device Manager.  Mine shows up as Silicon Labs CP210x USB to UART Bridge (COM3).  So this program example has COM3 hardcoded.

For Visual C# to access COMPorts, install the Top-level package "System.IO.Ports" by Microsoft 10.0.13.  

The device seems to require "\r\n" at the end of what you send it.   


