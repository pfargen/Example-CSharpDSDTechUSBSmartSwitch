using System.Data;

namespace DSD_TECH
{
    public partial class frmCOM3 : System.Windows.Forms.Form
    {
        SerialPortManager _serialPortManager = new SerialPortManager();
        public frmCOM3()
        {
            InitializeComponent();
        }

        private void Form_Load(object sender, EventArgs e)
        {
            Console.WriteLine("Starting frmCOM3");
        }

        private void cmdOpenCom3_Click(object sender, EventArgs e)
        {
            //_serialPortManager = new SerialPortManager();
            _serialPortManager.ConfigureAndOpenPort("COM3", 9600);
        }
        private void cmdCloseCOM3_Click(object sender, EventArgs e)
        {
            _serialPortManager.ClosePort();
        }
        private void cmdPing_Click(object sender, EventArgs e)
        {
            _serialPortManager.WriteData("AT\r\n");
        }
        private void OUT1ON_Click(object sender, EventArgs e)
        {
            _serialPortManager.WriteData("AT+CH1=1\r\n");
        }
        private void OUT1OFF_Click(object sender, EventArgs e)
        {
            _serialPortManager.WriteData("AT+CH1=0\r\n");
        }
        private void OUT1STATUS_Click(object sender, EventArgs e)
        {
            _serialPortManager.WriteData("AT+CH1=?\r\n");
        }

        private void OUT2ON_Click(object sender, EventArgs e)
        {
            _serialPortManager.WriteData("AT+CH2=1\r\n");
        }

        private void OUT2OFF_Click(object sender, EventArgs e)
        {
            _serialPortManager.WriteData("AT+CH2=0\r\n");
        }

        private void OUT2STATUS_Click(object sender, EventArgs e)
        {
            _serialPortManager.WriteData("AT+CH2=?\r\n");
        }

        private void OUT3ON_Click(object sender, EventArgs e)
        {
            _serialPortManager.WriteData("AT+CH3=1\r\n");
        }

        private void OUT3OFF_Click(object sender, EventArgs e)
        {
            _serialPortManager.WriteData("AT+CH3=0\r\n");
        }

        private void OUT3STATUS_Click(object sender, EventArgs e)
        {
            _serialPortManager.WriteData("AT+CH3=?\r\n");
        }

        private void OUT4ON_Click(object sender, EventArgs e)
        {
            _serialPortManager.WriteData("AT+CH4=1\r\n");
        }

        private void OUT4OFF_Click(object sender, EventArgs e)
        {
            _serialPortManager.WriteData("AT+CH4=0\r\n");
        }

        private void OUT4STATUS_Click(object sender, EventArgs e)
        {
            _serialPortManager.WriteData("AT+CH4=?\r\n");
        }

        private void ALLON_Click(object sender, EventArgs e)
        {
            OUT1ON_Click(sender, e);
            OUT2ON_Click(sender, e);
            OUT3ON_Click(sender, e);
            OUT4ON_Click(sender, e);
        }

        private void ALLOFF_Click(object sender, EventArgs e)
        {
            OUT1OFF_Click(sender, e);
            OUT2OFF_Click(sender, e);
            OUT3OFF_Click(sender, e);
            OUT4OFF_Click(sender, e);
        }

        private void ALLSTATUS_Click(object sender, EventArgs e)
        {
            OUT1STATUS_Click(sender, e);
            OUT2STATUS_Click(sender, e);
            OUT3STATUS_Click(sender, e);
            OUT4STATUS_Click(sender, e);
        }

        private void tmrLoop_Tick(object sender, EventArgs e)
        {
            ALLSTATUS_Click(sender, e);
            
        }
        private void UpdateStatus()
        {
            if (_serialPortManager.bOutputStatus[1] == 1)
                this.lblStatus1.Text = "ON";
            if (_serialPortManager.bOutputStatus[1] == 0)
                this.lblStatus1.Text = "OFF";
            if (_serialPortManager.bOutputStatus[2] == 1)
                this.lblStatus2.Text = "ON";
            if (_serialPortManager.bOutputStatus[2] == 0)
                this.lblStatus2.Text = "OFF";
            if (_serialPortManager.bOutputStatus[3] == 1)
                this.lblStatus3.Text = "ON";
            if (_serialPortManager.bOutputStatus[3] == 0)
                this.lblStatus3.Text = "OFF";
            if (_serialPortManager.bOutputStatus[4] == 1)
                this.lblStatus4.Text = "ON";
            if (_serialPortManager.bOutputStatus[4] == 0)
                this.lblStatus4.Text = "OFF";
        }

        private void tmrUpdateStatus_Tick(object sender, EventArgs e)
        {
            Console.WriteLine("Update Status");
            UpdateStatus();
        }
    }
}
