﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Text;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DSD_TECH
{

    class SerialPortManager
    {
        private SerialPort? _serialPort;
        public int[] bOutputStatus = new int[5] { 2, 2, 2, 2, 2 }; //The status will be 1-based since there are only 4, and the DSD Tech numbers the channels 1 to 4. 0=OFF, 1=ON, 2=UNKNOWN          

        public void ConfigureAndOpenPort(string portName, int baudRate = 9600)
        {
            // 1. Initialize with specific connection properties
            _serialPort = new SerialPort(portName, baudRate, Parity.None, 8, StopBits.One); //

            // 2. Set timeouts to prevent the application from hanging permanently
            _serialPort.ReadTimeout = 20000;//changed from 2 seconds to 20 seconds to allow for longer response times from the device
            _serialPort.WriteTimeout = 20000;

            // 3. Subscribe to the DataReceived event handler for reading asynchronously
            _serialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler); //

            try
            {
                _serialPort.Open(); //
                Console.WriteLine($"Port {portName} successfully opened.");
            }
            catch (Exception ex)
            {                
                Console.WriteLine($"Error opening port: {ex.Message}"); //
            }
        }

        // WRITE METHOD: Sending data
        public void WriteData(string textToSend)
        {
            if (_serialPort != null && _serialPort.IsOpen) //
            {
                try
                {
                    // Write line adds your default system newline character (e.g., \n or \r\n)
                    //_serialPort.WriteLine(textToSend); //

                    // Alternatively, use Write for raw strings or byte buffers:
                     _serialPort.Write(textToSend);
                    Console.Write($"Sent: {textToSend}");
                }
                catch (TimeoutException)
                {
                    Console.WriteLine("Write operation timed out.");
                }
            }
            else
            {
                if (_serialPort == null)
                    Console.WriteLine("_serialPort is null)");
                else
                {
                    if (_serialPort.IsOpen == false)
                        Console.WriteLine("_serialPort is not Open");
                }
            }
        }

        // READ METHOD: Triggered automatically whenever data enters the buffer
        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e) //
        {
            SerialPort sp = (SerialPort)sender; //
            try
            {
                // Read line assumes incoming data ends with a newline character
                string incomingData = sp.ReadLine(); //
                Console.WriteLine($"Received: {incomingData}");
                int iChannel = 0;
                int iStatus = 2;

                if (incomingData.Contains("OK+CH1"))
                    iChannel = 1;
                if (incomingData.Contains("OK+CH2"))
                    iChannel = 2;
                if (incomingData.Contains("OK+CH3"))
                    iChannel = 3;
                if (incomingData.Contains("OK+CH4"))
                    iChannel = 4;
                if (iChannel > 0 && iChannel < 5)
                {
                    if (incomingData.Contains("=0"))
                        iStatus = 0;
                    if (incomingData.Contains("=1"))
                        iStatus = 1;
                }
                if (iStatus < 2)
                {
                    bOutputStatus[iChannel] = iStatus;
                }

                /* 
                 * UI CRITICAL NOTE: If you are using Windows Forms or WPF, you cannot 
                 * update UI elements (like textboxes) directly from this handler because 
                 * it runs on a background thread. You must use Invoke:
                 * 
                 * this.Invoke(new Action(() => myTextBox.Text += incomingData)); //
                 */
            }
            catch (Exception ex)
            {
                //this will execute anytime the sender stops talking, so it is silenced for this app
                Console.WriteLine($"Error reading data: {ex.Message}");
            }
        }

        // CLOSE METHOD: Clean resource disposal
        public void ClosePort()
        {
            if (_serialPort != null && _serialPort.IsOpen) //
            {
                _serialPort.Close(); //
                _serialPort.Dispose();
                Console.WriteLine("Port closed cleanly.");
            }
            else
            {
                Console.WriteLine("Port is not open");
            }
        }
    }
}
