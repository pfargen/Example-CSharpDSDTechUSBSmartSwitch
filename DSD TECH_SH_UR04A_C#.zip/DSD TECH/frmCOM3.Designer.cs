﻿namespace DSD_TECH
{
    partial class frmCOM3
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            OpenCom3 = new Button();
            CloseCOM3 = new Button();
            cmdPing = new Button();
            OUT1ON = new Button();
            OUT1OFF = new Button();
            OUT1STATUS = new Button();
            OUT2STATUS = new Button();
            OUT2OFF = new Button();
            OUT2ON = new Button();
            OUT3STATUS = new Button();
            OUT3OFF = new Button();
            OUT3ON = new Button();
            OUT4STATUS = new Button();
            OUT4OFF = new Button();
            OUT4ON = new Button();
            ALLSTATUS = new Button();
            ALLOFF = new Button();
            ALLON = new Button();
            tmrLoop = new System.Windows.Forms.Timer(components);
            lblStatus1 = new Label();
            lblStatus2 = new Label();
            lblStatus3 = new Label();
            lblStatus4 = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            tmrUpdateStatus = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // OpenCom3
            // 
            OpenCom3.Location = new Point(12, 21);
            OpenCom3.Name = "OpenCom3";
            OpenCom3.Size = new Size(99, 36);
            OpenCom3.TabIndex = 0;
            OpenCom3.Text = "Open COM3";
            OpenCom3.UseVisualStyleBackColor = true;
            OpenCom3.Click += cmdOpenCom3_Click;
            // 
            // CloseCOM3
            // 
            CloseCOM3.Location = new Point(117, 21);
            CloseCOM3.Name = "CloseCOM3";
            CloseCOM3.Size = new Size(99, 36);
            CloseCOM3.TabIndex = 3;
            CloseCOM3.Text = "Close COM3";
            CloseCOM3.UseVisualStyleBackColor = true;
            CloseCOM3.Click += cmdCloseCOM3_Click;
            // 
            // cmdPing
            // 
            cmdPing.Location = new Point(222, 21);
            cmdPing.Name = "cmdPing";
            cmdPing.Size = new Size(99, 36);
            cmdPing.TabIndex = 4;
            cmdPing.Text = "Ping";
            cmdPing.UseVisualStyleBackColor = true;
            cmdPing.Click += cmdPing_Click;
            // 
            // OUT1ON
            // 
            OUT1ON.Location = new Point(12, 76);
            OUT1ON.Name = "OUT1ON";
            OUT1ON.Size = new Size(99, 36);
            OUT1ON.TabIndex = 1;
            OUT1ON.Text = "Out1 ON";
            OUT1ON.UseVisualStyleBackColor = true;
            OUT1ON.Click += OUT1ON_Click;
            // 
            // OUT1OFF
            // 
            OUT1OFF.Location = new Point(12, 118);
            OUT1OFF.Name = "OUT1OFF";
            OUT1OFF.Size = new Size(99, 36);
            OUT1OFF.TabIndex = 2;
            OUT1OFF.Text = "Out1 OFF";
            OUT1OFF.UseVisualStyleBackColor = true;
            OUT1OFF.Click += OUT1OFF_Click;
            // 
            // OUT1STATUS
            // 
            OUT1STATUS.Location = new Point(12, 160);
            OUT1STATUS.Name = "OUT1STATUS";
            OUT1STATUS.Size = new Size(99, 36);
            OUT1STATUS.TabIndex = 5;
            OUT1STATUS.Text = "OUT1 Status";
            OUT1STATUS.UseVisualStyleBackColor = true;
            OUT1STATUS.Click += OUT1STATUS_Click;
            // 
            // OUT2STATUS
            // 
            OUT2STATUS.Location = new Point(117, 160);
            OUT2STATUS.Name = "OUT2STATUS";
            OUT2STATUS.Size = new Size(99, 36);
            OUT2STATUS.TabIndex = 8;
            OUT2STATUS.Text = "Out2 Status";
            OUT2STATUS.UseVisualStyleBackColor = true;
            OUT2STATUS.Click += OUT2STATUS_Click;
            // 
            // OUT2OFF
            // 
            OUT2OFF.Location = new Point(117, 118);
            OUT2OFF.Name = "OUT2OFF";
            OUT2OFF.Size = new Size(99, 36);
            OUT2OFF.TabIndex = 7;
            OUT2OFF.Text = "Out2 OFF";
            OUT2OFF.UseVisualStyleBackColor = true;
            OUT2OFF.Click += OUT2OFF_Click;
            // 
            // OUT2ON
            // 
            OUT2ON.Location = new Point(117, 76);
            OUT2ON.Name = "OUT2ON";
            OUT2ON.Size = new Size(99, 36);
            OUT2ON.TabIndex = 6;
            OUT2ON.Text = "Out2 ON";
            OUT2ON.UseVisualStyleBackColor = true;
            OUT2ON.Click += OUT2ON_Click;
            // 
            // OUT3STATUS
            // 
            OUT3STATUS.Location = new Point(222, 160);
            OUT3STATUS.Name = "OUT3STATUS";
            OUT3STATUS.Size = new Size(99, 36);
            OUT3STATUS.TabIndex = 11;
            OUT3STATUS.Text = "OUT3 Status";
            OUT3STATUS.UseVisualStyleBackColor = true;
            OUT3STATUS.Click += OUT3STATUS_Click;
            // 
            // OUT3OFF
            // 
            OUT3OFF.Location = new Point(222, 118);
            OUT3OFF.Name = "OUT3OFF";
            OUT3OFF.Size = new Size(99, 36);
            OUT3OFF.TabIndex = 10;
            OUT3OFF.Text = "Out3 OFF";
            OUT3OFF.UseVisualStyleBackColor = true;
            OUT3OFF.Click += OUT3OFF_Click;
            // 
            // OUT3ON
            // 
            OUT3ON.Location = new Point(222, 76);
            OUT3ON.Name = "OUT3ON";
            OUT3ON.Size = new Size(99, 36);
            OUT3ON.TabIndex = 9;
            OUT3ON.Text = "Out3 ON";
            OUT3ON.UseVisualStyleBackColor = true;
            OUT3ON.Click += OUT3ON_Click;
            // 
            // OUT4STATUS
            // 
            OUT4STATUS.Location = new Point(327, 160);
            OUT4STATUS.Name = "OUT4STATUS";
            OUT4STATUS.Size = new Size(99, 36);
            OUT4STATUS.TabIndex = 14;
            OUT4STATUS.Text = "Out4 Status";
            OUT4STATUS.UseVisualStyleBackColor = true;
            OUT4STATUS.Click += OUT4STATUS_Click;
            // 
            // OUT4OFF
            // 
            OUT4OFF.Location = new Point(327, 118);
            OUT4OFF.Name = "OUT4OFF";
            OUT4OFF.Size = new Size(99, 36);
            OUT4OFF.TabIndex = 13;
            OUT4OFF.Text = "Out4 OFF";
            OUT4OFF.UseVisualStyleBackColor = true;
            OUT4OFF.Click += OUT4OFF_Click;
            // 
            // OUT4ON
            // 
            OUT4ON.Location = new Point(327, 76);
            OUT4ON.Name = "OUT4ON";
            OUT4ON.Size = new Size(99, 36);
            OUT4ON.TabIndex = 12;
            OUT4ON.Text = "Out4 ON";
            OUT4ON.UseVisualStyleBackColor = true;
            OUT4ON.Click += OUT4ON_Click;
            // 
            // ALLSTATUS
            // 
            ALLSTATUS.Location = new Point(432, 160);
            ALLSTATUS.Name = "ALLSTATUS";
            ALLSTATUS.Size = new Size(99, 36);
            ALLSTATUS.TabIndex = 17;
            ALLSTATUS.Text = "ALL STATUS";
            ALLSTATUS.UseVisualStyleBackColor = true;
            ALLSTATUS.Click += ALLSTATUS_Click;
            // 
            // ALLOFF
            // 
            ALLOFF.Location = new Point(432, 118);
            ALLOFF.Name = "ALLOFF";
            ALLOFF.Size = new Size(99, 36);
            ALLOFF.TabIndex = 16;
            ALLOFF.Text = "ALL OFF";
            ALLOFF.UseVisualStyleBackColor = true;
            ALLOFF.Click += ALLOFF_Click;
            // 
            // ALLON
            // 
            ALLON.Location = new Point(432, 76);
            ALLON.Name = "ALLON";
            ALLON.Size = new Size(99, 36);
            ALLON.TabIndex = 15;
            ALLON.Text = "ALL ON";
            ALLON.UseVisualStyleBackColor = true;
            ALLON.Click += ALLON_Click;
            // 
            // tmrLoop
            // 
            tmrLoop.Enabled = true;
            tmrLoop.Interval = 10000;
            tmrLoop.Tick += tmrLoop_Tick;
            // 
            // lblStatus1
            // 
            lblStatus1.AutoSize = true;
            lblStatus1.Location = new Point(40, 199);
            lblStatus1.Name = "lblStatus1";
            lblStatus1.Size = new Size(40, 15);
            lblStatus1.TabIndex = 18;
            lblStatus1.Text = "UNKN";
            // 
            // lblStatus2
            // 
            lblStatus2.AutoSize = true;
            lblStatus2.Location = new Point(145, 199);
            lblStatus2.Name = "lblStatus2";
            lblStatus2.Size = new Size(40, 15);
            lblStatus2.TabIndex = 19;
            lblStatus2.Text = "UNKN";
            // 
            // lblStatus3
            // 
            lblStatus3.AutoSize = true;
            lblStatus3.Location = new Point(249, 199);
            lblStatus3.Name = "lblStatus3";
            lblStatus3.Size = new Size(40, 15);
            lblStatus3.TabIndex = 20;
            lblStatus3.Text = "UNKN";
            // 
            // lblStatus4
            // 
            lblStatus4.AutoSize = true;
            lblStatus4.Location = new Point(354, 199);
            lblStatus4.Name = "lblStatus4";
            lblStatus4.Size = new Size(40, 15);
            lblStatus4.TabIndex = 21;
            lblStatus4.Text = "UNKN";
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 10000;
            // 
            // tmrUpdateStatus
            // 
            tmrUpdateStatus.Enabled = true;
            tmrUpdateStatus.Tick += tmrUpdateStatus_Tick;
            // 
            // frmCOM3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(543, 284);
            Controls.Add(lblStatus4);
            Controls.Add(lblStatus3);
            Controls.Add(lblStatus2);
            Controls.Add(lblStatus1);
            Controls.Add(ALLSTATUS);
            Controls.Add(ALLOFF);
            Controls.Add(ALLON);
            Controls.Add(OUT4STATUS);
            Controls.Add(OUT4OFF);
            Controls.Add(OUT4ON);
            Controls.Add(OUT3STATUS);
            Controls.Add(OUT3OFF);
            Controls.Add(OUT3ON);
            Controls.Add(OUT2STATUS);
            Controls.Add(OUT2OFF);
            Controls.Add(OUT2ON);
            Controls.Add(OUT1STATUS);
            Controls.Add(cmdPing);
            Controls.Add(CloseCOM3);
            Controls.Add(OUT1OFF);
            Controls.Add(OUT1ON);
            Controls.Add(OpenCom3);
            Name = "frmCOM3";
            Text = "COM3 DSD TECH Model: SH-UR04";
            Load += Form_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button OpenCom3;
        private Button OUT1ON;
        private Button OUT1OFF;
        private Button CloseCOM3;
        private Button cmdPing;
        private Button OUT1STATUS;
        private Button OUT2STATUS;
        private Button OUT2OFF;
        private Button OUT2ON;
        private Button OUT3STATUS;
        private Button OUT3OFF;
        private Button OUT3ON;
        private Button OUT4STATUS;
        private Button OUT4OFF;
        private Button OUT4ON;
        private Button ALLSTATUS;
        private Button ALLOFF;
        private Button ALLON;
        private System.Windows.Forms.Timer tmrLoop;
        private Label lblStatus1;
        private Label lblStatus2;
        private Label lblStatus3;
        private Label lblStatus4;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer tmrUpdateStatus;
    }
}
